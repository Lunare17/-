# replit.md

## Overview

**Version 1.0 Complete** - This is a full-stack web application built for routine and activity management with a circular timetable interface. The application features a React frontend with TypeScript, an Express backend, and uses PostgreSQL with Drizzle ORM for data persistence. The UI is built using shadcn/ui components with Radix UI primitives and styled with Tailwind CSS.

### Key Features (v1.0)
- **Real-time Circular Timetable**: 24-hour clock with moving hour, minute, and second hands
- **Routine Management**: Create, edit, delete recurring routines with color-coded fan sectors
- **Daily Activity Tracking**: Calendar-based activity recording separate from routines
- **Dual View Interface**: Toggle between routine management and calendar views
- **Korean Language Interface**: Fully localized for Korean users
- **Mobile-Responsive Design**: Optimized for mobile devices

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for development
- **Routing**: Wouter for client-side routing (lightweight alternative to React Router)
- **State Management**: TanStack React Query for server state management
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ES modules
- **API Pattern**: RESTful API with CRUD operations
- **Validation**: Zod schemas for request/response validation
- **Middleware**: Custom logging middleware for API requests

### Data Storage
- **Database**: PostgreSQL (configured for production)
- **ORM**: Drizzle ORM with type-safe schema definitions
- **Connection**: Neon Database serverless adapter
- **Development**: In-memory storage implementation for local development
- **Migrations**: Drizzle Kit for schema management

## Key Components

### Database Schema
- **Routines Table**: Stores recurring schedule templates with name, start/end times, and color
- **Activities Table**: Stores daily activities linked to specific dates with timing and color

### Frontend Components
- **CircularTimetable**: 24-hour circular clock visualization with routine/activity sectors
- **CalendarView**: Monthly calendar interface for date selection and activity management
- **RoutineList**: CRUD interface for managing routine templates
- **Modal Components**: Forms for creating/editing routines and activities

### Backend Services
- **Storage Interface**: Abstracted storage layer supporting both in-memory and database implementations
- **Route Handlers**: RESTful endpoints for routines and activities with full CRUD operations
- **Validation Layer**: Zod schema validation for all API inputs

## Data Flow

1. **Client Requests**: Frontend makes HTTP requests to `/api/*` endpoints
2. **Validation**: Server validates requests using Zod schemas
3. **Storage Operations**: Abstracted storage layer handles data persistence
4. **Response**: Type-safe responses sent back to client
5. **State Management**: TanStack Query manages caching and synchronization
6. **UI Updates**: React components re-render based on query state

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection for serverless environments
- **@tanstack/react-query**: Server state management and caching
- **drizzle-orm**: Type-safe database operations
- **react-hook-form**: Form state management
- **zod**: Runtime type validation
- **wouter**: Lightweight client-side routing

### UI Dependencies
- **@radix-ui/***: Unstyled, accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Component variant management
- **lucide-react**: Icon library

### Development Dependencies
- **vite**: Fast development build tool with HMR
- **typescript**: Static type checking
- **drizzle-kit**: Database schema management
- **esbuild**: Production server bundling

## Deployment Strategy

### Development
- **Frontend**: Vite dev server with HMR
- **Backend**: tsx for TypeScript execution with file watching
- **Database**: In-memory storage for local development
- **Environment**: NODE_ENV=development

### Production
- **Frontend**: Static build output to `dist/public`
- **Backend**: Bundled with esbuild to `dist/index.js`
- **Database**: PostgreSQL via DATABASE_URL environment variable
- **Serving**: Express serves both API and static files
- **Environment**: NODE_ENV=production

### Build Process
1. Frontend builds to static files
2. Backend bundles with external packages
3. Database migrations applied via `drizzle-kit push`
4. Single Node.js process serves everything

The architecture emphasizes type safety throughout the stack, with shared TypeScript types between client and server, and uses modern development practices with fast rebuild times and hot module replacement.