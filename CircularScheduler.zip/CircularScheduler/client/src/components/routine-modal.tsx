import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { X } from "lucide-react";
import { insertRoutineSchema, type InsertRoutine, type Routine } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";

interface RoutineModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (routine: InsertRoutine) => void;
  editingRoutine?: Routine | null;
}

const defaultColors = [
  "#F44336", "#2196F3", "#4CAF50", "#FF9800", 
  "#9C27B0", "#E91E63", "#607D8B", "#795548"
];

export function RoutineModal({ isOpen, onClose, onSave, editingRoutine }: RoutineModalProps) {
  const form = useForm<InsertRoutine>({
    resolver: zodResolver(insertRoutineSchema),
    defaultValues: {
      name: editingRoutine?.name || "",
      startTime: editingRoutine?.startTime || "09:00",
      endTime: editingRoutine?.endTime || "10:00",
      color: editingRoutine?.color || "#4CAF50",
    },
  });

  const selectedColor = form.watch("color");

  const handleSubmit = (data: InsertRoutine) => {
    onSave(data);
    form.reset();
    onClose();
  };

  const handleClose = () => {
    form.reset();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            {editingRoutine ? "루틴 수정" : "루틴 추가"}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
          <div>
            <Label htmlFor="name">루틴 이름</Label>
            <Input
              id="name"
              placeholder="예: 아침 운동"
              {...form.register("name")}
            />
            {form.formState.errors.name && (
              <p className="text-sm text-red-600 mt-1">
                {form.formState.errors.name.message}
              </p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="startTime">시작 시간</Label>
              <Input
                id="startTime"
                type="time"
                {...form.register("startTime")}
              />
              {form.formState.errors.startTime && (
                <p className="text-sm text-red-600 mt-1">
                  {form.formState.errors.startTime.message}
                </p>
              )}
            </div>
            <div>
              <Label htmlFor="endTime">종료 시간</Label>
              <Input
                id="endTime"
                type="time"
                {...form.register("endTime")}
              />
              {form.formState.errors.endTime && (
                <p className="text-sm text-red-600 mt-1">
                  {form.formState.errors.endTime.message}
                </p>
              )}
            </div>
          </div>

          <div>
            <Label>색상 선택</Label>
            <div className="flex space-x-2 mt-2">
              {defaultColors.map((color) => (
                <button
                  key={color}
                  type="button"
                  className={cn(
                    "w-8 h-8 rounded-full border-2 transition-all",
                    selectedColor === color 
                      ? "border-gray-800 scale-110" 
                      : "border-gray-300 hover:border-gray-400"
                  )}
                  style={{ backgroundColor: color }}
                  onClick={() => form.setValue("color", color)}
                />
              ))}
            </div>
          </div>

          <div className="flex space-x-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              className="flex-1"
            >
              취소
            </Button>
            <Button type="submit" className="flex-1 bg-primary hover:bg-primary/90">
              저장
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
