import { useEffect, useRef } from "react";
import { getCurrentTime, timeToAngle, createSectorPath, formatDisplayTime } from "@/lib/time-utils";
import type { Routine, Activity } from "@shared/schema";

interface CircularTimetableProps {
  routines?: Routine[];
  activities?: Activity[];
  size?: number;
  showClock?: boolean;
  onSectorClick?: (routine: Routine) => void;
}

export function CircularTimetable({ 
  routines = [], 
  activities = [], 
  size = 280, 
  showClock = true,
  onSectorClick 
}: CircularTimetableProps) {
  const hourHandRef = useRef<SVGLineElement>(null);
  const minuteHandRef = useRef<SVGLineElement>(null);
  const secondHandRef = useRef<SVGLineElement>(null);
  const timeDisplayRef = useRef<HTMLSpanElement>(null);

  const center = size / 2;
  const radius = (size / 2) - 50;

  useEffect(() => {
    if (!showClock) return;

    const updateClock = () => {
      const { hours, minutes, seconds } = getCurrentTime();
      
      // Update digital display
      if (timeDisplayRef.current) {
        timeDisplayRef.current.textContent = formatDisplayTime(hours, minutes, seconds);
      }

      // Update clock hands
      if (hourHandRef.current && minuteHandRef.current && secondHandRef.current) {
        // Calculate angles for 24-hour format (24 hours = 360 degrees)
        // Each hour is 15 degrees (360/24), each minute is 0.25 degrees (15/60)
        const hourAngle = ((hours % 24) * 15) + (minutes * 0.25) - 90;
        // Traditional minute hand: 60 minutes = 360 degrees, each minute is 6 degrees
        const minuteAngle = (minutes * 6) + (seconds * 0.1) - 90;
        // Second hand: 60 seconds = 360 degrees, each second is 6 degrees
        const secondAngle = (seconds * 6) - 90;

        hourHandRef.current.style.transform = `rotate(${hourAngle}deg)`;
        minuteHandRef.current.style.transform = `rotate(${minuteAngle}deg)`;
        secondHandRef.current.style.transform = `rotate(${secondAngle}deg)`;
      }
    };

    updateClock();
    const interval = setInterval(updateClock, 1000);

    return () => clearInterval(interval);
  }, [showClock]);

  const renderHourMarkers = () => {
    const markers = [];
    for (let i = 0; i < 24; i++) {
      const angle = (i * 15) - 90; // 24 hours = 360 degrees
      const isMainHour = i % 3 === 0;
      const markerLength = isMainHour ? 15 : 8;
      const strokeWidth = isMainHour ? 2 : 1;
      
      const x1 = center + (radius + 10) * Math.cos((angle * Math.PI) / 180);
      const y1 = center + (radius + 10) * Math.sin((angle * Math.PI) / 180);
      const x2 = center + (radius + 10 - markerLength) * Math.cos((angle * Math.PI) / 180);
      const y2 = center + (radius + 10 - markerLength) * Math.sin((angle * Math.PI) / 180);

      markers.push(
        <line
          key={`marker-${i}`}
          x1={x1}
          y1={y1}
          x2={x2}
          y2={y2}
          stroke="#666"
          strokeWidth={strokeWidth}
        />
      );

      if (isMainHour) {
        const textX = center + (radius + 25) * Math.cos((angle * Math.PI) / 180);
        const textY = center + (radius + 25) * Math.sin((angle * Math.PI) / 180);
        
        markers.push(
          <text
            key={`text-${i}`}
            x={textX}
            y={textY}
            textAnchor="middle"
            dominantBaseline="middle"
            className="text-xs font-medium fill-gray-600"
          >
            {i}
          </text>
        );
      }
    }
    return markers;
  };

  const renderSectors = () => {
    const sectors: JSX.Element[] = [];
    const dataSource = activities.length > 0 ? activities : routines;

    dataSource.forEach((item, index) => {
      const startAngle = timeToAngle(item.startTime);
      const endAngle = timeToAngle(item.endTime);
      
      let adjustedEndAngle = endAngle;
      if (endAngle <= startAngle) {
        adjustedEndAngle = endAngle + 360;
      }

      const path = createSectorPath(center, center, radius, startAngle, adjustedEndAngle);

      sectors.push(
        <path
          key={`sector-${item.id}`}
          d={path}
          fill={item.color}
          fillOpacity={0.7}
          stroke={item.color}
          strokeWidth={1}
          className="cursor-pointer transition-all duration-300 hover:opacity-80 hover:stroke-[3px]"
          onClick={() => onSectorClick && 'name' in item && onSectorClick(item as Routine)}
        />
      );
    });

    return sectors;
  };

  return (
    <div className="relative flex flex-col items-center">
      {/* Current time display - moved above the clock */}
      {showClock && (
        <div className="mb-4">
          <div className="bg-primary text-white px-4 py-2 rounded-full text-sm font-medium shadow-lg">
            <span ref={timeDisplayRef}>--:--:--</span>
          </div>
        </div>
      )}

      <svg width={size} height={size} className="drop-shadow-lg">
        {/* Background circle */}
        <circle
          cx={center}
          cy={center}
          r={radius + 10}
          fill="#FFFFFF"
          stroke="#E0E0E0"
          strokeWidth={2}
        />

        {/* Hour markers */}
        {renderHourMarkers()}

        {/* Routine/Activity sectors */}
        {renderSectors()}

        {/* Clock hands (only shown when showClock is true) */}
        {showClock && (
          <>
            {/* Hour hand */}
            <line
              ref={hourHandRef}
              x1={center}
              y1={center}
              x2={center}
              y2={center - radius * 0.5}
              stroke="#333"
              strokeWidth={4}
              strokeLinecap="round"
              style={{ transformOrigin: `${center}px ${center}px` }}
              className="transition-transform duration-100 ease-out"
            />

            {/* Minute hand */}
            <line
              ref={minuteHandRef}
              x1={center}
              y1={center}
              x2={center}
              y2={center - radius * 0.7}
              stroke="#333"
              strokeWidth={3}
              strokeLinecap="round"
              style={{ transformOrigin: `${center}px ${center}px` }}
              className="transition-transform duration-100 ease-out"
            />

            {/* Second hand */}
            <line
              ref={secondHandRef}
              x1={center}
              y1={center}
              x2={center}
              y2={center - radius * 0.8}
              stroke="#F44336"
              strokeWidth={1}
              strokeLinecap="round"
              style={{ transformOrigin: `${center}px ${center}px` }}
              className="transition-transform duration-100 ease-out"
            />

            {/* Center dot */}
            <circle cx={center} cy={center} r={6} fill="#333" />
          </>
        )}
      </svg>
    </div>
  );
}
