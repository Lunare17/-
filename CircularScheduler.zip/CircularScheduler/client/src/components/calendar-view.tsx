import { useState } from "react";
import { ChevronLeft, ChevronRight, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CircularTimetable } from "./circular-timetable";
import { ActivityModal } from "./activity-modal";
import type { Activity, InsertActivity } from "@shared/schema";
import { cn } from "@/lib/utils";

interface CalendarViewProps {
  selectedDate: string;
  onDateChange: (date: string) => void;
  activities: Activity[];
  onSaveActivity: (activity: InsertActivity) => void;
  onDeleteActivity: (id: number) => void;
}

export function CalendarView({
  selectedDate,
  onDateChange,
  activities,
  onSaveActivity,
  onDeleteActivity,
}: CalendarViewProps) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [isActivityModalOpen, setIsActivityModalOpen] = useState(false);
  const [editingActivity, setEditingActivity] = useState<Activity | null>(null);

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const firstDayOfMonth = new Date(year, month, 1);
  const lastDayOfMonth = new Date(year, month + 1, 0);
  const startDate = new Date(firstDayOfMonth);
  startDate.setDate(startDate.getDate() - firstDayOfMonth.getDay());

  const calendarDays = [];
  const currentIterDate = new Date(startDate);

  for (let i = 0; i < 42; i++) {
    calendarDays.push(new Date(currentIterDate));
    currentIterDate.setDate(currentIterDate.getDate() + 1);
  }

  const formatDate = (date: Date): string => {
    return date.toISOString().split('T')[0];
  };

  const formatDisplayDate = (dateStr: string): string => {
    const date = new Date(dateStr);
    return `${date.getMonth() + 1}월 ${date.getDate()}일`;
  };

  const goToPreviousMonth = () => {
    setCurrentDate(new Date(year, month - 1));
  };

  const goToNextMonth = () => {
    setCurrentDate(new Date(year, month + 1));
  };

  const handleDateClick = (date: Date) => {
    onDateChange(formatDate(date));
  };

  const handleAddActivity = () => {
    setEditingActivity(null);
    setIsActivityModalOpen(true);
  };

  const handleEditActivity = (activity: Activity) => {
    setEditingActivity(activity);
    setIsActivityModalOpen(true);
  };

  const calculateDuration = (startTime: string, endTime: string): string => {
    const [startHour, startMin] = startTime.split(':').map(Number);
    const [endHour, endMin] = endTime.split(':').map(Number);
    
    let startMinutes = startHour * 60 + startMin;
    let endMinutes = endHour * 60 + endMin;
    
    if (endMinutes < startMinutes) {
      endMinutes += 24 * 60; // Handle overnight activities
    }
    
    const durationMinutes = endMinutes - startMinutes;
    const hours = Math.floor(durationMinutes / 60);
    const minutes = durationMinutes % 60;
    
    if (hours === 0) return `${minutes}분`;
    if (minutes === 0) return `${hours}시간`;
    return `${hours}시간 ${minutes}분`;
  };

  return (
    <div className="space-y-6">
      {/* Calendar Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-800">
          {year}년 {month + 1}월
        </h3>
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="sm" onClick={goToPreviousMonth}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={goToNextMonth}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Calendar Grid */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-7 gap-1 mb-2">
            {['일', '월', '화', '수', '목', '금', '토'].map((day) => (
              <div key={day} className="text-center text-sm font-medium text-gray-600 py-2">
                {day}
              </div>
            ))}
          </div>
          
          <div className="grid grid-cols-7 gap-1">
            {calendarDays.map((date, index) => {
              const dateStr = formatDate(date);
              const isCurrentMonth = date.getMonth() === month;
              const isSelected = dateStr === selectedDate;
              
              return (
                <button
                  key={index}
                  onClick={() => handleDateClick(date)}
                  className={cn(
                    "text-center text-sm p-2 rounded transition-all",
                    isCurrentMonth
                      ? "text-gray-800 hover:bg-gray-50"
                      : "text-gray-400",
                    isSelected && "bg-primary text-white hover:bg-primary/90"
                  )}
                >
                  {date.getDate()}
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Selected Date Activities */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-semibold text-gray-800">
              {formatDisplayDate(selectedDate)} 활동 기록
            </h4>
            <Button onClick={handleAddActivity} size="sm">
              <Plus className="h-4 w-4 mr-1" />
              추가
            </Button>
          </div>
          
          {/* Mini circular view for selected date */}
          {activities.length > 0 && (
            <div className="flex justify-center mb-4">
              <CircularTimetable
                activities={activities}
                size={200}
                showClock={false}
              />
            </div>
          )}
          
          {/* Activity list */}
          <div className="space-y-2">
            {activities.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-500 mb-2">기록된 활동이 없습니다</p>
                <p className="text-sm text-gray-400">활동을 추가해보세요</p>
              </div>
            ) : (
              activities.map((activity) => (
                <div
                  key={activity.id}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100"
                  onClick={() => handleEditActivity(activity)}
                >
                  <div className="flex items-center space-x-3">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: activity.color }}
                    />
                    <div>
                      <span className="text-sm font-medium text-gray-800">
                        {activity.name}
                      </span>
                      <span className="text-xs text-gray-600 ml-2">
                        {calculateDuration(activity.startTime, activity.endTime)}
                      </span>
                    </div>
                  </div>
                  <span className="text-xs text-gray-500">
                    {activity.startTime}-{activity.endTime}
                  </span>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      <ActivityModal
        isOpen={isActivityModalOpen}
        onClose={() => setIsActivityModalOpen(false)}
        onSave={onSaveActivity}
        selectedDate={selectedDate}
        editingActivity={editingActivity}
      />
    </div>
  );
}
