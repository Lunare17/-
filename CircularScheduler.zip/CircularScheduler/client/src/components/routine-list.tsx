import { Edit, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import type { Routine } from "@shared/schema";

interface RoutineListProps {
  routines: Routine[];
  onEditRoutine: (routine: Routine) => void;
  onDeleteRoutine: (id: number) => void;
}

export function RoutineList({ routines, onEditRoutine, onDeleteRoutine }: RoutineListProps) {
  if (routines.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500 mb-4">등록된 루틴이 없습니다</p>
        <p className="text-sm text-gray-400">+ 버튼을 눌러 새로운 루틴을 추가해보세요</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">내 루틴</h3>
      
      {routines.map((routine) => (
        <Card key={routine.id} className="transition-all duration-200 hover:-translate-y-1 hover:shadow-md">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div 
                  className="w-4 h-4 rounded-full" 
                  style={{ backgroundColor: routine.color }}
                />
                <div>
                  <h4 className="font-medium text-gray-800">{routine.name}</h4>
                  <p className="text-sm text-gray-600">
                    {routine.startTime} - {routine.endTime}
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onEditRoutine(routine)}
                  className="p-2 h-8 w-8"
                >
                  <Edit className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onDeleteRoutine(routine.id)}
                  className="p-2 h-8 w-8 hover:bg-red-50 hover:text-red-600"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
