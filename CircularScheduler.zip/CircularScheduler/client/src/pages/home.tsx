import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Clock, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { CircularTimetable } from "@/components/circular-timetable";
import { RoutineList } from "@/components/routine-list";
import { CalendarView } from "@/components/calendar-view";
import { RoutineModal } from "@/components/routine-modal";
import type { Routine, Activity, InsertRoutine, InsertActivity } from "@shared/schema";
import { cn } from "@/lib/utils";
import { getCurrentTime, formatDisplayTime } from "@/lib/time-utils";

type ViewMode = "routine" | "calendar";

export default function Home() {
  const [viewMode, setViewMode] = useState<ViewMode>("routine");
  const [selectedDate, setSelectedDate] = useState(() => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  });
  const [isRoutineModalOpen, setIsRoutineModalOpen] = useState(false);
  const [editingRoutine, setEditingRoutine] = useState<Routine | null>(null);
  const [currentTime, setCurrentTime] = useState(getCurrentTime());

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Update current time every second
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(getCurrentTime());
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  // Fetch routines
  const { data: routines = [], isLoading: routinesLoading } = useQuery<Routine[]>({
    queryKey: ["/api/routines"],
  });

  // Fetch activities for selected date
  const { data: activities = [], isLoading: activitiesLoading } = useQuery<Activity[]>({
    queryKey: ["/api/activities", selectedDate],
    queryFn: async () => {
      const response = await fetch(`/api/activities?date=${selectedDate}`);
      if (!response.ok) throw new Error('Failed to fetch activities');
      return response.json();
    },
  });

  // Routine mutations
  const createRoutineMutation = useMutation({
    mutationFn: async (routine: InsertRoutine) => {
      const response = await apiRequest("POST", "/api/routines", routine);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/routines"] });
      toast({
        title: "루틴이 생성되었습니다",
        description: "새로운 루틴이 성공적으로 추가되었습니다.",
      });
    },
    onError: () => {
      toast({
        title: "오류",
        description: "루틴 생성 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });

  const updateRoutineMutation = useMutation({
    mutationFn: async ({ id, routine }: { id: number; routine: InsertRoutine }) => {
      const response = await apiRequest("PUT", `/api/routines/${id}`, routine);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/routines"] });
      toast({
        title: "루틴이 수정되었습니다",
        description: "루틴이 성공적으로 업데이트되었습니다.",
      });
    },
    onError: () => {
      toast({
        title: "오류",
        description: "루틴 수정 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });

  const deleteRoutineMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/routines/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/routines"] });
      toast({
        title: "루틴이 삭제되었습니다",
        description: "루틴이 성공적으로 삭제되었습니다.",
      });
    },
    onError: () => {
      toast({
        title: "오류",
        description: "루틴 삭제 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });

  // Activity mutations
  const createActivityMutation = useMutation({
    mutationFn: async (activity: InsertActivity) => {
      const response = await apiRequest("POST", "/api/activities", activity);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/activities", selectedDate] });
      toast({
        title: "활동이 기록되었습니다",
        description: "새로운 활동이 성공적으로 추가되었습니다.",
      });
    },
    onError: () => {
      toast({
        title: "오류",
        description: "활동 기록 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });

  const deleteActivityMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/activities/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/activities", selectedDate] });
      toast({
        title: "활동이 삭제되었습니다",
        description: "활동이 성공적으로 삭제되었습니다.",
      });
    },
    onError: () => {
      toast({
        title: "오류",
        description: "활동 삭제 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });

  // Handlers
  const handleSaveRoutine = (routine: InsertRoutine) => {
    if (editingRoutine) {
      updateRoutineMutation.mutate({ id: editingRoutine.id, routine });
    } else {
      createRoutineMutation.mutate(routine);
    }
    setEditingRoutine(null);
  };

  const handleEditRoutine = (routine: Routine) => {
    setEditingRoutine(routine);
    setIsRoutineModalOpen(true);
  };

  const handleDeleteRoutine = (id: number) => {
    if (confirm("이 루틴을 삭제하시겠습니까?")) {
      deleteRoutineMutation.mutate(id);
    }
  };

  const handleAddRoutine = () => {
    setEditingRoutine(null);
    setIsRoutineModalOpen(true);
  };

  const handleSaveActivity = (activity: InsertActivity) => {
    createActivityMutation.mutate(activity);
  };

  const handleDateChange = (date: string) => {
    setSelectedDate(date);
  };

  if (routinesLoading || activitiesLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-gray-600">로딩 중...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-md mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-semibold text-gray-800">CircleTime</h1>
            <div className="text-sm font-medium text-gray-600">
              {formatDisplayTime(currentTime.hours, currentTime.minutes, currentTime.seconds)}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-md mx-auto px-4 py-6">
        {/* Tab Navigation */}
        <div className="flex bg-white rounded-lg p-1 mb-6 shadow-sm">
          <Button
            variant={viewMode === "routine" ? "default" : "ghost"}
            onClick={() => setViewMode("routine")}
            className={cn(
              "flex-1 text-sm font-medium",
              viewMode === "routine" && "bg-primary text-white"
            )}
          >
            <Clock className="h-4 w-4 mr-1" />
            루틴 관리
          </Button>
          <Button
            variant={viewMode === "calendar" ? "default" : "ghost"}
            onClick={() => setViewMode("calendar")}
            className={cn(
              "flex-1 text-sm font-medium",
              viewMode === "calendar" && "bg-primary text-white"
            )}
          >
            <Calendar className="h-4 w-4 mr-1" />
            캘린더
          </Button>
        </div>

        {/* Routine Management View */}
        {viewMode === "routine" && (
          <div className="space-y-8">
            {/* Circular Timetable */}
            <div className="flex justify-center">
              <CircularTimetable
                routines={routines}
                onSectorClick={handleEditRoutine}
              />
            </div>

            {/* Routine List */}
            <RoutineList
              routines={routines}
              onEditRoutine={handleEditRoutine}
              onDeleteRoutine={handleDeleteRoutine}
            />
          </div>
        )}

        {/* Calendar View */}
        {viewMode === "calendar" && (
          <CalendarView
            selectedDate={selectedDate}
            onDateChange={handleDateChange}
            activities={activities}
            onSaveActivity={handleSaveActivity}
            onDeleteActivity={deleteActivityMutation.mutate}
          />
        )}
      </main>

      {/* Floating Action Button */}
      {viewMode === "routine" && (
        <div className="fixed bottom-6 right-6">
          <Button
            onClick={handleAddRoutine}
            className="bg-primary text-white p-4 rounded-full shadow-lg hover:bg-primary/90 transition-all hover:scale-105"
            size="sm"
          >
            <Plus className="h-6 w-6" />
          </Button>
        </div>
      )}

      {/* Routine Modal */}
      <RoutineModal
        isOpen={isRoutineModalOpen}
        onClose={() => setIsRoutineModalOpen(false)}
        onSave={handleSaveRoutine}
        editingRoutine={editingRoutine}
      />
    </div>
  );
}
