import { 
  routines, 
  activities, 
  type Routine, 
  type Activity,
  type InsertRoutine, 
  type InsertActivity 
} from "@shared/schema";

export interface IStorage {
  // Routine CRUD operations
  getRoutines(): Promise<Routine[]>;
  getRoutine(id: number): Promise<Routine | undefined>;
  createRoutine(routine: InsertRoutine): Promise<Routine>;
  updateRoutine(id: number, routine: Partial<InsertRoutine>): Promise<Routine | undefined>;
  deleteRoutine(id: number): Promise<boolean>;
  
  // Activity CRUD operations
  getActivities(date: string): Promise<Activity[]>;
  getActivity(id: number): Promise<Activity | undefined>;
  createActivity(activity: InsertActivity): Promise<Activity>;
  updateActivity(id: number, activity: Partial<InsertActivity>): Promise<Activity | undefined>;
  deleteActivity(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private routines: Map<number, Routine>;
  private activities: Map<number, Activity>;
  private currentRoutineId: number;
  private currentActivityId: number;

  constructor() {
    this.routines = new Map();
    this.activities = new Map();
    this.currentRoutineId = 1;
    this.currentActivityId = 1;
  }

  async getRoutines(): Promise<Routine[]> {
    return Array.from(this.routines.values());
  }

  async getRoutine(id: number): Promise<Routine | undefined> {
    return this.routines.get(id);
  }

  async createRoutine(insertRoutine: InsertRoutine): Promise<Routine> {
    const id = this.currentRoutineId++;
    const routine: Routine = { 
      ...insertRoutine, 
      id,
      color: insertRoutine.color || "#4CAF50"
    };
    this.routines.set(id, routine);
    return routine;
  }

  async updateRoutine(id: number, updateData: Partial<InsertRoutine>): Promise<Routine | undefined> {
    const routine = this.routines.get(id);
    if (!routine) return undefined;
    
    const updatedRoutine = { ...routine, ...updateData };
    this.routines.set(id, updatedRoutine);
    return updatedRoutine;
  }

  async deleteRoutine(id: number): Promise<boolean> {
    return this.routines.delete(id);
  }

  async getActivities(date: string): Promise<Activity[]> {
    return Array.from(this.activities.values()).filter(
      activity => activity.date === date
    );
  }

  async getActivity(id: number): Promise<Activity | undefined> {
    return this.activities.get(id);
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = this.currentActivityId++;
    const activity: Activity = { 
      ...insertActivity, 
      id,
      color: insertActivity.color || "#4CAF50"
    };
    this.activities.set(id, activity);
    return activity;
  }

  async updateActivity(id: number, updateData: Partial<InsertActivity>): Promise<Activity | undefined> {
    const activity = this.activities.get(id);
    if (!activity) return undefined;
    
    const updatedActivity = { ...activity, ...updateData };
    this.activities.set(id, updatedActivity);
    return updatedActivity;
  }

  async deleteActivity(id: number): Promise<boolean> {
    return this.activities.delete(id);
  }
}

export const storage = new MemStorage();
