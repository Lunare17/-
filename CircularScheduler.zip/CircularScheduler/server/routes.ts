import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertRoutineSchema, insertActivitySchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Routine routes
  app.get("/api/routines", async (req, res) => {
    try {
      const routines = await storage.getRoutines();
      res.json(routines);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch routines" });
    }
  });

  app.post("/api/routines", async (req, res) => {
    try {
      const validatedData = insertRoutineSchema.parse(req.body);
      const routine = await storage.createRoutine(validatedData);
      res.status(201).json(routine);
    } catch (error) {
      res.status(400).json({ message: "Invalid routine data" });
    }
  });

  app.put("/api/routines/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertRoutineSchema.partial().parse(req.body);
      const routine = await storage.updateRoutine(id, validatedData);
      
      if (!routine) {
        res.status(404).json({ message: "Routine not found" });
        return;
      }
      
      res.json(routine);
    } catch (error) {
      res.status(400).json({ message: "Invalid routine data" });
    }
  });

  app.delete("/api/routines/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteRoutine(id);
      
      if (!deleted) {
        res.status(404).json({ message: "Routine not found" });
        return;
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete routine" });
    }
  });

  // Activity routes
  app.get("/api/activities", async (req, res) => {
    try {
      const date = req.query.date as string;
      if (!date) {
        res.status(400).json({ message: "Date parameter is required" });
        return;
      }
      
      const activities = await storage.getActivities(date);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });

  app.post("/api/activities", async (req, res) => {
    try {
      const validatedData = insertActivitySchema.parse(req.body);
      const activity = await storage.createActivity(validatedData);
      res.status(201).json(activity);
    } catch (error) {
      res.status(400).json({ message: "Invalid activity data" });
    }
  });

  app.put("/api/activities/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertActivitySchema.partial().parse(req.body);
      const activity = await storage.updateActivity(id, validatedData);
      
      if (!activity) {
        res.status(404).json({ message: "Activity not found" });
        return;
      }
      
      res.json(activity);
    } catch (error) {
      res.status(400).json({ message: "Invalid activity data" });
    }
  });

  app.delete("/api/activities/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteActivity(id);
      
      if (!deleted) {
        res.status(404).json({ message: "Activity not found" });
        return;
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete activity" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
